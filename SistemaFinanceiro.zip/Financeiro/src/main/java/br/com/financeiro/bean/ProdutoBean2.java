package br.com.financeiro.bean;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.omnifaces.util.Messages;

import br.com.financeiro.dao.ProdutoDAO;
import br.com.financeiro.domain.Produto;

@ViewScoped
@ManagedBean
public class ProdutoBean2 {

	private Produto produto;
	
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public Produto getProduto() {
		return produto;
	}
	
	@PostConstruct
	public void novo() {
		produto = new Produto();
	
	}
	
	public void buscar() {
		try {
			ProdutoDAO dao = new ProdutoDAO();
			Produto produto1 = new Produto();
			 produto1 = dao.buscar(produto.getCodigo());
			
			if(produto1==null) {
				Messages.addGlobalInfo("Esse Produto Não Existe!!");
			}else {
				produto = produto1;
			}
		}catch(RuntimeException ex) {
			throw ex;
		}
	}
}
