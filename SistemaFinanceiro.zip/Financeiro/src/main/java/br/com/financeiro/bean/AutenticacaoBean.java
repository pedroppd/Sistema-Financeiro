package br.com.financeiro.bean;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.omnifaces.util.Faces;
import org.omnifaces.util.Messages;

import br.com.financeiro.dao.UsuarioDAO;
import br.com.financeiro.domain.Pessoa;
import br.com.financeiro.domain.Usuario;

@ManagedBean
@SessionScoped
public class AutenticacaoBean {

	private Usuario usuario;
	private Usuario logado;
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Usuario getLogado() {
		return logado;
	}
	public void setLogado(Usuario logado) {
		this.logado = logado;
	}
	
	@PostConstruct
	public void novo() {
		usuario = new Usuario();
		usuario.setPessoa(new Pessoa());
	}
	
	public void autenticar() throws IOException {
		try {
			UsuarioDAO dao = new UsuarioDAO();
			logado = dao.autenticar(usuario.getPessoa().getCpf(), usuario.getSenha());
			if(logado==null) {
				Messages.addGlobalError("CPF ou SENHA incorretos");
			}else {
				Faces.redirect("./pages/produto.xhtml");
			}
			
		}catch(IOException ex) {
			throw ex;
		}
	}
	
	
	public boolean temPermissoes(List<String>permissoes) {
		for(String permissao : permissoes) {
			if(logado.getTipo()==permissao.charAt(0)) {
				return true;
			}
		}
		return false;
	}
}
