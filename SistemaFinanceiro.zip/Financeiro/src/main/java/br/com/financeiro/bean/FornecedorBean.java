package br.com.financeiro.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.financeiro.dao.FornecedorDAO;
import br.com.financeiro.domain.Fornecedor;

@SuppressWarnings("serial")
@ViewScoped
@ManagedBean
public class FornecedorBean implements Serializable{

	
	
	private Fornecedor fornecedor;
	private List<Fornecedor> fornecedores;

	public Fornecedor getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public List<Fornecedor> getFornecedores() {
		return fornecedores;
	}

	public void setFornecedores(List<Fornecedor> fornecedores) {
		this.fornecedores = fornecedores;
	}

	@PostConstruct
	public void listar() {
		try {
			FornecedorDAO dao = new FornecedorDAO();

			fornecedores = dao.listar();
		} catch (RuntimeException ex) {
			throw ex;
		}
	}

	public void salvar() {
		try {

			FornecedorDAO dao = new FornecedorDAO();

			dao.merge(fornecedor);

			fornecedores = dao.listar();
			Messages.addGlobalInfo("Fornecedor salvo com sucesso!!");
		} catch (RuntimeException ex) {
			throw ex;
		}
	}

	public void novo() {
		try {

			fornecedor = new Fornecedor();
		
		} catch (RuntimeException ex) {
			throw ex;

		}
	}

	public void excluir(ActionEvent evento) {
		try {
			fornecedor = (Fornecedor) evento.getComponent().getAttributes().get("fornecedorSelecionado");
			FornecedorDAO dao = new FornecedorDAO();
			dao.excluir(fornecedor);

			fornecedores = dao.listar();

			Messages.addGlobalInfo("Fornecedor excluído com sucesso!!");
		} catch (RuntimeException ex) {
			throw ex;
		}
	}

	public void editar(ActionEvent evento) {
		try {
			fornecedor = (Fornecedor) evento.getComponent().getAttributes().get("fornecedorSelecionado");
			FornecedorDAO dao = new FornecedorDAO();
			fornecedores = dao.listar();

			Messages.addGlobalInfo("Fornecedor excluído com sucesso!!");
		} catch (RuntimeException ex) {
			throw ex;
		}
	}

}
