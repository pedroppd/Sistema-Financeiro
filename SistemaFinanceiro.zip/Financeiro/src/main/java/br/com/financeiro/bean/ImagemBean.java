package br.com.financeiro.bean;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.persistence.MappedSuperclass;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import br.com.financeiro.domain.Produto;

@ManagedBean
@RequestScoped
@MappedSuperclass
public class ImagemBean {

	@ManagedProperty("#{param.caminho}")
	private String caminho;
	
	private StreamedContent foto;
	
	
	
	
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}

	public StreamedContent getFoto() {
		return foto;
	}

	public void setFoto(StreamedContent foto) {
		this.foto = foto;
	}

	public String getCaminho() throws IOException{
		if(caminho==null || caminho.isEmpty()) {
			Path path = Paths.get("E:/Sistema-Financeiro/upload/branco.jpg");
			InputStream stream = Files.newInputStream(path);
			foto = new DefaultStreamedContent(stream);
		}else {
			Path path = Paths.get(caminho);
			InputStream stream = Files.newInputStream(path);
			foto = new DefaultStreamedContent(stream);
		}
		
		return caminho;
	}
	
	
	
	
	
}
