package br.com.financeiro.dao;

import br.com.financeiro.domain.Fornecedor;

public class FornecedorDAO extends GenericDAO<Fornecedor>{

}
