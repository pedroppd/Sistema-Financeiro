package br.com.financeiro.dao;

import br.com.financeiro.domain.ItemVenda;

public class ItemVendaDAO extends GenericDAO<ItemVenda>{

}
