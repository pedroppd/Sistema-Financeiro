package br.com.financeiro.dao;

import br.com.financeiro.domain.Produto;

public class ProdutoDAO extends GenericDAO<Produto>{

}
