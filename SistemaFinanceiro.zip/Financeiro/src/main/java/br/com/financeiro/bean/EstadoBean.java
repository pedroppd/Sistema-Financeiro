package br.com.financeiro.bean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import br.com.financeiro.dao.EstadoDAO;
import br.com.financeiro.domain.Estado;

@ManagedBean(name="MBestado")
@ViewScoped
public class EstadoBean {

	private Estado estado;
	
	private List<Estado>estados;
	
	
	

	public List<Estado> getEstados() {
		return estados;
	}

	public void setEstados(List<Estado> estados) {
		this.estados = estados;
	}

	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}

	// METODO PARA GERAR UM NOVO ESTADO
	public void novo() {

		estado = new Estado();
	}

	// METODO PARA SALVAR UM ESTADO
	public void salvar() {
	try {
		EstadoDAO estadoDAO = new EstadoDAO();
		estadoDAO.merge(estado);

		novo();
		estados = estadoDAO.listar();
		Messages.addGlobalInfo("Estado salvo com sucesso");
	} catch (RuntimeException erro) {
		Messages.addGlobalError("Ocorreu um erro ao tentar salvar o estado");
		erro.printStackTrace();
	}
}
	
	//METODO PARA LISTAR
	@PostConstruct
	public void listar(){
		try{
			EstadoDAO estadoDAO = new EstadoDAO();
			estados = estadoDAO.listar();
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Ocorreu um erro ao tentar listar os estados");
			erro.printStackTrace();
		}
	}
	
	
	//METODO PARA EXCLUIR
	public void excluir(ActionEvent evento) {
		try {
			estado = (Estado) evento.getComponent().getAttributes().get("estadoSelecionado");

			EstadoDAO estadoDAO = new EstadoDAO();
			estadoDAO.excluir(estado);
			
			estados = estadoDAO.listar();

			Messages.addGlobalInfo("Estado removido com sucesso");
		} catch (RuntimeException erro) {
			Messages.addFlashGlobalError("Ocorreu um erro ao tentar remover o estado");
			erro.printStackTrace();
		}
	}
	
	//METODO PARA EDITAR
	public void editar(ActionEvent evento){
		estado = (Estado) evento.getComponent().getAttributes().get("estadoSelecionado");
	}





	

}
