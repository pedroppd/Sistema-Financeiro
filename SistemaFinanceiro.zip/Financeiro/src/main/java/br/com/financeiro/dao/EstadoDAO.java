package br.com.financeiro.dao;

import br.com.financeiro.domain.Estado;

public class EstadoDAO extends GenericDAO<Estado>{

}
