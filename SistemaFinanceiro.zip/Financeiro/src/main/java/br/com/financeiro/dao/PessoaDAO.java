package br.com.financeiro.dao;

import br.com.financeiro.domain.Pessoa;

public class PessoaDAO extends GenericDAO<Pessoa>{

}
