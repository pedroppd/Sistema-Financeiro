package br.com.financeiro.dao;

import java.util.List;

import org.hibernate.Session;

import br.com.financeiro.domain.Venda;
import br.com.financeiro.util.HibernateUtil;

import org.hibernate.Transaction;
import org.omnifaces.util.Messages;

import br.com.financeiro.domain.ItemVenda;
import br.com.financeiro.domain.Produto;

public class VendaDAO extends GenericDAO<Venda> {
	public void salvar(Venda venda, List<ItemVenda> itensVenda){
		Session sessao = HibernateUtil.getSessionFactory().openSession();
		Transaction transacao = null;

		try {
			transacao = sessao.beginTransaction();
		
			sessao.save(venda);
			
			for(int posicao = 0; posicao < itensVenda.size(); posicao++){
				ItemVenda itemVenda = itensVenda.get(posicao);
				itemVenda.setVenda(venda);
				sessao.save(itemVenda);		
				Produto produto = itemVenda.getProduto();
				
				int qtde = produto.getQuantidade()-itemVenda.getQuantidade();
			
				if(qtde>=0) {
				produto.setQuantidade(new Short((qtde)+""));
				
				sessao.update(produto);
				
				}else {
					Messages.addGlobalError("Não temos esse produto em estoque :(");
				}
			}
			
			
			transacao.commit();
		} catch (RuntimeException erro) {
			if (transacao != null) {
				transacao.rollback();
			}
			throw erro;
		} finally {
			sessao.close();
		}
	}
}


