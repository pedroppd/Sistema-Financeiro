package br.com.financeiro.dao;

import org.junit.Ignore;
import org.junit.Test;

import br.com.financeiro.domain.Pessoa;

public class PessoaDaoTest {

	@Test
	@Ignore
	public void salvar() {
		Pessoa pessoa = new Pessoa();
		
		pessoa.setBairro("Barro Vermelho");
		pessoa.setCelular("88728190");
		pessoa.setCep("24416060");
		pessoa.setComplemento("Praça");
		pessoa.setCpf("125.164.537-28");
		pessoa.setEmail("pedro_pdantas@hotmail.com");
		pessoa.setNome("Pedro Dantas");
		pessoa.setNumero(new Short("1"));
		pessoa.setRg("12543588");
		pessoa.setRua("Trav alberto pitta");
		pessoa.setTelefone("2628-7244");
		
		
		PessoaDAO dao = new PessoaDAO();
		
		dao.salvar(pessoa);
		
	}
}
