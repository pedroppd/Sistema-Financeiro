package br.com.financeiro.dao;

import org.junit.Test;

import br.com.financeiro.domain.Fornecedor;

public class FornecedorDaoTeste {

	@Test
	public void salvar() {
		Fornecedor f = new Fornecedor();
		
		f.setDescricao("teste 04");
		
		FornecedorDAO dao = new FornecedorDAO();
		
		dao.salvar(f);
	}
}
