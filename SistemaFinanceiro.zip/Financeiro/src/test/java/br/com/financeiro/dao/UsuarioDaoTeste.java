package br.com.financeiro.dao;

import org.junit.Test;

import br.com.financeiro.domain.Pessoa;
import br.com.financeiro.domain.Usuario;

public class UsuarioDaoTeste {

	@Test
	public void salvar() {
		Usuario u = new Usuario();
		PessoaDAO daop = new PessoaDAO();
		
		Pessoa p = daop.buscar(1L);
		
		
		
		u.setAtivo(true);
		u.setSenha("123");
		u.setTipo('G');
		u.setPessoa(p);
		
		UsuarioDAO dao = new UsuarioDAO();
		
		dao.salvar(u);
		
	}
}
